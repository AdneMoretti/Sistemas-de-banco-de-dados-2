-- ---------------------   << Exercício 2 da Aula 1  >>   ---------------------
--
--                    SCRIPT DE CRIAÇÃO (DDL)
-- 
-- Data Criacao ...........: 03/04/2023
-- Autor(es) ..............: Cainã Valença de Freitas, Adne Moretti Moreira
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ...: aula1exer2
-- 
-- Ultimas alteracoes
-- Adicionando tabela AREA e alguns atributos
-- 
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula1exer2
    DEFAULT CHARACTER SET utf8
    DEFAULT COLLATE utf8_general_ci;
USE aula1exer2;


CREATE TABLE PESSOA (
    cpf BIGINT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    senha VARCHAR(8) NOT NULL,
    
    CONSTRAINT PESSOA_PK PRIMARY KEY (cpf)
) ENGINE = InnoDB;

CREATE TABLE EMPREGADO (
    matricula INT(8) NOT NULL,
    cpf BIGINT NOT NULL UNIQUE,
    estado VARCHAR(50) NOT NULL,
    cidade VARCHAR(50) NOT NULL,
    bairro VARCHAR(50) NOT NULL,
    rua VARCHAR(50) NOT NULL,
    numero INT(5) NOT NULL,
    
    CONSTRAINT EMPREGADO_PK PRIMARY KEY (matricula),
    CONSTRAINT EMPREGADO_PESSOA_FK FOREIGN KEY (cpf)
        REFERENCES PESSOA(cpf)
) ENGINE = InnoDB;

CREATE TABLE GERENTE (
    cpf BIGINT NOT NULL,
    email VARCHAR(50) NOT NULL,
    formacao VARCHAR(50) NOT NULL,

	CONSTRAINT GERENTE_PK PRIMARY KEY (cpf),
    CONSTRAINT GERENTE_PESSOA_FK FOREIGN KEY (cpf)
        REFERENCES PESSOA(cpf)
) ENGINE = InnoDB;

CREATE TABLE AREA(
	idArea INT(5) AUTO_INCREMENT NOT NULL, 
    nomeArea VARCHAR(50) NOT NULL, 
	CONSTRAINT AREA_PK PRIMARY KEY (idArea)
) ENGINE=InnoDB;

CREATE TABLE supervisiona (
    cpfGerente BIGINT NOT NULL,
    idArea INT(5) NOT NULL,

	CONSTRAINT supervisiona_GERENTE_FK FOREIGN KEY (cpfGerente)
		REFERENCES GERENTE(cpf),
    CONSTRAINT supervisiona_AREA_FK FOREIGN KEY (idArea)
        REFERENCES AREA(idArea)
) ENGINE = InnoDB;

CREATE TABLE telefone (
    telefone BIGINT NOT NULL,
    matricula INT(8) NOT NULL,

	CONSTRAINT telefone_PK PRIMARY KEY (telefone),
    CONSTRAINT telefone_EMPREGADO_FK FOREIGN KEY (matricula)
        REFERENCES EMPREGADO(matricula)
) ENGINE = InnoDB;

CREATE TABLE VENDA (
    idVenda INT(8) AUTO_INCREMENT NOT NULL,
    matricula INT(8) NOT NULL,
    dataVenda DATE NOT NULL UNIQUE,

	CONSTRAINT VENDA_PK PRIMARY KEY (idVenda),
    CONSTRAINT VENDA_EMPREGADO_FK FOREIGN KEY (matricula)
        REFERENCES EMPREGADO(matricula)
) ENGINE = InnoDB;

CREATE TABLE PRODUTO (
    idProduto INT(8) AUTO_INCREMENT NOT NULL,
    descricao VARCHAR(50) NOT NULL,
    precoUnico DECIMAL(7,2) NOT NULL,

	CONSTRAINT PRODUTO_PK PRIMARY KEY (idProduto)
) ENGINE = InnoDB;

CREATE TABLE compoe (
    idVenda INT(8) NOT NULL,
    idProduto INT(8) NOT NULL,
    quantidade INT(5) NOT NULL, 

	CONSTRAINT compoe_VENDA_FK FOREIGN KEY (idVenda)
        REFERENCES VENDA(idVenda),
    CONSTRAINT compoe_PRODUTO_FK FOREIGN KEY (idProduto)
        REFERENCES PRODUTO(idProduto)
) ENGINE = InnoDB;

