-- ---------------------   << Exercício 2 da Aula 1 Evolucao 2 >>   ---------------------
--
--                    SCRIPT DE POPULAR (DML)
-- 
-- Data Criacao ...........: 03/04/2023
-- Autor(es) ..............: Cainã Valença de Freitas, Adne Moretti Moreira
-- Banco de Dados .........: MySQL
-- Base de Dados(nome) ...: aula1exer2Evolucao2
-- 
-- Ultimas alteracoes -
-- 11/04/2023 - Adicionando tabela de AREA e mais tuplas
-- 
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- 
-- -----------------------------------------------------------------

USE aula1exer2;

INSERT INTO
	PESSOA(cpf, nome, senha)
VALUES
('12345678901', 'João da Silva', 'senha123'),
('98765432109', 'Maria Souza', 'abc123'),
('11122233344', 'Pedro Alves', 'p@ssword'),
('55566677788', 'Ana Oliveira', 'secret'),
('99988877766', 'Lucas Santos', 'qwerty'),
('33322211100', 'Carla Fernandes', 'letmein'),
('34512647223', 'Davi de Oliveira', 'user123'),
('08598378743', 'Joana Linhares', 'abelhinh'),
('33325311100', 'Gabriel Costa', '223844'),
('06856473839', 'Gabriel Moreira', '223844'), 
('32623428400', 'Andreia de Moura', '223844');

INSERT INTO 
	GERENTE(cpf, email, formacao)
VALUES
('12345678901', 'joao.silva@empresa.com', 'Superior Completo'),
('98765432109', 'maria.souza@empresa.com', 'Médio Completo'),
('11122233344', 'pedro.alves@empresa.com', 'Doutor'), 
('33322211100', 'Gabriel Costa', 'Superior incompleto'), 
('06856473839', 'Gabriel Moreira', 'Médio incompleto'), 
('32623428400', 'Andreia de Moura', 'Superior');

INSERT INTO 
	EMPREGADO(matricula, cpf, estado, cidade, bairro, rua, numero)
VALUES
('11111', '55566677788', 'PE', 'Recife', 'Boa Viagem', 'Avenida Boa Viagem', 100),
('22222', '99988877766', 'RS', 'Porto Alegre', 'Moinhos de Vento', 'Rua Padre Chagas', 300),
('33333', '33322211100', 'BA', 'Salvador', 'Barra', 'Avenida Oceânica', 50), 
('44444', '34512647223', 'RJ', 'Rio de Janeiro', 'Barra', 'Tijuca', 30),
('55555', '08598378743', 'BA', 'Salvador', 'Barra', 'Avenida Oceânica', 10),
('66666', '06856473839', 'SP', 'Sao Paulo', 'Paulo', 'Piracanjuba', 7);

INSERT INTO AREA VALUES 
(NULL, 'Sapatos'),
(NULL, 'Camisas'), 
(NULL, 'Bomboniere'), 
(NULL, 'Eletrodomesticos'), 
(NULL, 'Eletronicos'),
(NULL, 'Flores');

INSERT INTO 
	supervisiona (cpfGerente, idArea)
VALUES
('12345678901','1'),
('98765432109','2'),
('11122233344','3'), 
('33322211100','4'), 
('06856473839','5'), 
('32623428400','6');

INSERT INTO
	telefone (telefone, matricula)
VALUES
('1199998888', '11111'),
('1188887777', '22222'),
('2133334444', '33333'),
('6199254361', '44444'),
('6185541131', '55555'),
('6299312763', '66666');

INSERT INTO 
	VENDA (matricula, dataVenda)
VALUES
('11111', '1990-05-15'),
('22222', '1987-10-05'),
('33333', '2003-09-12'), 
('44444', '2022-06-19'), 
('55555', '2023-01-03'), 
('66666', '2021-05-05');

INSERT INTO
	PRODUTO (descricao, precoUnico)
VALUES
('Caneta Azul', 1.99),
('Caderno Universitário', 15.99),
('Lápis de Cor', 4.50),
('Borracha Branca', 0.99),
('Mochila Escolar', 89.99),
('Livro de Matemática', 25.50),
('Régua 30cm', 2.99);

INSERT INTO 
	compoe (idVenda, idProduto, quantidade)
VALUES
(1, '1', 2),
(2, '2', 5),
(3, '3', 6), 
(4, '4', 8), 
(5, '5', 7), 
(6, '6', 12);
