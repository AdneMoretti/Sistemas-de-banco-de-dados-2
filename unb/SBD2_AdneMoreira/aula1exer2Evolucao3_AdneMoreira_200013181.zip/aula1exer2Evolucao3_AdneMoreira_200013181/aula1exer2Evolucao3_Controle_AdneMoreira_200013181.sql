-- ---------------------   << Exercício 2 da Aula 1 Evolucao 3 >>   ---------------------
--
--                    			SCRIPT APAGA (DDL)
-- 
-- Data Criacao ...........: 14/04/2023
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL8.0
-- Base de Dados(nome) ...: aula1exer2Evolucao3
-- 
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 		   => 03 Papeis
-- 		   => 08 Usuarios
-- 
-- -----------------------------------------------------------------

USE aula1exer2Evolucao3;

-- Criacao de papeis
CREATE ROLE superior;
CREATE ROLE gerente;
CREATE ROLE empregado;

-- Atribuindo privilegios aos papeis

GRANT ALL PRIVILEGES
	ON aula1exer2Evolucao3.* 
	TO superior;
    
GRANT SELECT 
	ON aula1exer2Evolucao3.* 
	TO empregado;
    
GRANT INSERT 
	ON aula1exer2Evolucao3.VENDA 
    TO empregado;
    
GRANT SELECT 
	ON aula1exer2Evolucao3.PESSOA 
    TO gerente; 
    
GRANT SELECT
	ON aula1exer2Evolucao3.EMPREGADO 
    TO gerente; 
    
GRANT SELECT 
	ON aula1exer2Evolucao3.GERENTE 
	TO gerente; 

GRANT SELECT, INSERT, DELETE, UPDATE 
	ON aula1exer2Evolucao3.VENDA
    TO gerente;
    
GRANT SELECT, INSERT, DELETE, UPDATE 
	ON aula1exer2Evolucao3.AREA
    TO gerente;
    
GRANT SELECT, INSERT, DELETE, UPDATE 
	ON aula1exer2Evolucao3.PRODUTO
    TO gerente;
    
GRANT SELECT, INSERT, DELETE, UPDATE 
	ON aula1exer2Evolucao3.compoe
    TO gerente;
    
-- Criação de usuários

CREATE USER 'admin' 
	IDENTIFIED BY '1admin';
    
CREATE USER 'anamaria'  
	IDENTIFIED BY '2anam ';
 
 CREATE USER 'ruicarlos'
	IDENTIFIED BY '3ruic ';
    
CREATE USER 'maria' 
	IDENTIFIED BY '4maria';
    
CREATE USER 'paulo'  
	IDENTIFIED BY '5paulo ';
 
 CREATE USER 'jose'  
	IDENTIFIED BY '6jose';
    
CREATE USER 'giovana'  
	IDENTIFIED BY '7giovana';
    
CREATE USER 'pedro'  
	IDENTIFIED BY '8pedro';
    
-- Designando papeis para os Usuarios
 
GRANT superior TO admin;
GRANT gerente TO anamaria;
GRANT gerente TO ruicarlos;
GRANT empregado TO maria;
GRANT empregado TO paulo;
GRANT empregado TO jose;
GRANT empregado TO giovana;
GRANT empregado TO pedro;