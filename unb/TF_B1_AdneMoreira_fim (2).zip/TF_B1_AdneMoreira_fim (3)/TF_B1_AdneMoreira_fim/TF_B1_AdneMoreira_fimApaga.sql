﻿-- ---------------------- TF_B1_AdneMoreira ----------------------------
--
--                    SCRIPT APAGA (DDL)
--
-- Data Criacao ...........: 09/07/2018
-- Autor(es) ..............: Adne Moreira, Gabriel Oliveira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: imdb_ijs
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 
-- ---------------------------------------------------------

USE imdb_ijs;

DROP TABLE directors_genres;
DROP TABLE movies_genres;
DROP TABLE movies_directors;
DROP TABLE roles;
DROP TABLE actors;
DROP TABLE directors;
DROP TABLE movies;