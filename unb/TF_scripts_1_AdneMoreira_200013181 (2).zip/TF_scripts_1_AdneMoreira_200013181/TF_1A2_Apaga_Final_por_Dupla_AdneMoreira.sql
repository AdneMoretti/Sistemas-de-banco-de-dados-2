--   ----------------- TF_1A2_AdneMoreira ----------------
--                    SCRIPT APAGA (DDL)
--
-- Data Criacao ...........: 05/02/2023
-- Autor(es) ..............: Adne Moretti Moreira, Ana Beatriz Massuh
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1A2_AdneMoreira
-- 
-- Ultimas Alteracoes
--   05/02/2023 => Apagando roles e adicionando tabelas MENSALIDADE e AVALIACAO
--               
-- PROJETO => 01 Base de Dados
--         => 10 Tabelas
--
-- ---------------------------------------------------------
USE TF_1A2_AdneMoreira;

DROP USER EvelynTeresinhaDC;
DROP USER MelissaAndreaDA;
DROP USER AdministradorJoao;
DROP ROLE ADMINISTRADOR;
DROP ROLE AUTONOMO;
DROP ROLE USUARIO;
DROP TABLE atua;
DROP TABLE possui; 
DROP TABLE PAGAMENTO;
DROP TABLE CARTAO;
DROP TABLE AVALIACAO;
DROP TABLE MENSALIDADE;
DROP TABLE SERVICO;
DROP TABLE FORNECEDOR;
DROP TABLE CLIENTE;
DROP TABLE AREAATUACAO;
