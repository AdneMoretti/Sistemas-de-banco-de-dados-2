--   ----------------- TF_1A2_AdneMoreira ----------------
--                    SCRIPT DE CONTROLE (DCL)
--
-- Data Criacao ...........: 25/01/2023
-- Autor(es) ..............: Adne Moretti Moreira, Ana Beatriz Massuh
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: TF_1A2_AdneMoreira
--            
--
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- ---------------------------------------------------------

USE TF_1A2_AdneMoreira;

-- Criacao de perfil
CREATE ROLE USUARIO;
CREATE ROLE AUTONOMO;
CREATE ROLE ADMINISTRADOR;

-- Atribuindo privilegios
GRANT ALL PRIVILEGES ON TF_1A2_AdneMoreira TO ADMINISTRADOR;
GRANT UPDATE, SELECT, INSERT ON TF_1A2_AdneMoreira.FORNECEDOR TO AUTONOMO;
GRANT ALL PRIVILEGES ON TF_1A2_AdneMoreira.SERVICO TO AUTONOMO;
GRANT ALL PRIVILEGES ON TF_1A2_AdneMoreira.SERVICO TO AUTONOMO;