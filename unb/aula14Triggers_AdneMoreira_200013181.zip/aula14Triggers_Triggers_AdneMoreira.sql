-- -------------   << aula13Triggers >>   ---------------
--
--                  SCRIPT DE CRIACAO (DDL)
--
-- Data de Criacao ........: 02/07/2023
-- Autor(es) ..............: Adne Moreira
-- Banco de Dados .........: MySql 8.0
-- Base de Dados (nome) ...: aula13Triggers
--
-- PROJETO => 01 Base de Dados
--         => 04 Tabelas
--         => 03 Triggers
--
-- -------------------------------------------------------

-- BASE DE DADOS
USE aula13Triggers;


DELIMITER ||
CREATE TRIGGER trg_1 BEFORE INSERT ON tbl_cliente 
	FOR EACH ROW 
    BEGIN
    set @nome = NEW.cliente_nome;
    IF ((CHAR_LENGTH(@nome) <= 4) OR (@nome='')) THEN 
		SET NEW.cliente_nome=NULL;
	END IF;
END ||


DELIMITER ||
CREATE TRIGGER trg_2 BEFORE INSERT ON tbl_compra 
	FOR EACH ROW 
    BEGIN
    SELECT COUNT(cliente_id) INTO @cliente_id 
    WHERE cliente_id = @cliente_id;
	SELECT COUNT(produto_id) INTO @produto_id 
    WHERE cliente_id = @produto_id;
    IF ((@cliente_id = 0) OR (@produto_id=0)) THEN 
		SET NEW.cliente_id=NULL;
        SET NEW.produto_id=NULL;
	END IF;
END ||
    
    
DELIMITER ||
CREATE TRIGGER trg_3 BEFORE INSERT ON tbl_cliente 
	FOR EACH ROW 
    BEGIN
    IF (NEW.cliente_email IS NOT NULL) THEN 
		INSERT INTO tbl_newsletter SET news_email = NEW.cliente_email;
	END IF;
END ||
