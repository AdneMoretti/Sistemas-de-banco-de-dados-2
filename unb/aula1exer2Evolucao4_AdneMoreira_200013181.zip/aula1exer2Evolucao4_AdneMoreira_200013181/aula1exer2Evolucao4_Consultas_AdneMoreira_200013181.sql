-- ---------------------   << Exercício 2 da Aula 1 Evolucao 4 >>   ---------------------
--
--                    		SCRIPT DE CONSULTA(DML)
-- 
-- Data Criacao ...........: 03/04/2023
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL8.0
-- Base de Dados(nome) ...: aula1exer2Evolucao4
--
-- 
-- PROJETO => 01 Base de Dados
--         => 08 Tabelas
-- 		   => 03 Papeis
-- 		   => 08 Usuarios
-- 
-- -----------------------------------------------------------------

USE aula1exer2Evolucao4;

-- A) Consultar todas as vendas feitas por um empregado específico que será definido pelo usuário através da chave primária do 
-- empregado nessa pesquisa (usuário definirá um empregado específico na consulta);

SELECT * FROM VENDA WHERE matricula = 1111;

-- B) Relacionar todos os dados de uma venda específica com todas as informações dos produtos comercializados por esta venda e mostrar
-- o preço total por item da venda (usuário definirá uma venda específica na consulta);

SELECT v.idVenda, v.matricula, v.dataVenda, p.precoUnico 
	FROM VENDA v 
		INNER JOIN compoe c ON v.idVenda=c.idVenda
			INNER JOIN PRODUTO p ON c.idProduto=p.idProduto 
				WHERE v.idVenda = 1;


--  C) Mostrar todos os empregados da empresa que NÃO sejam gerentes em ordem alfabética crescente do nome do empregado;

SELECT p.nome
	FROM EMPREGADO e LEFT JOIN GERENTE g ON g.cpfGerente = e.cpf
		JOIN PESSOA p ON p.cpf = e.cpf
			WHERE g.cpfGerente IS NULL ORDER BY p.nome ASC;
        
-- D) Consultar e mostrar a quantidade de CADA produto que foi vendido por esta empresa (lembrar que só o código do produto não identifica qual produto é para vários funcionários ou usuários finais da empresa, 
-- então reflita de quais atributos deverão ser apresentados e em qual sequência para atender o interesse do usuário final em suas atividades diárias com melhor qualidade e eficiência);

SELECT p.descricao, COUNT(c.quantidade) quantidade
	FROM PRODUTO p, compoe c WHERE p.idProduto = c.idProduto
		GROUP BY p.idProduto;

-- E) Solicitar ao usuário qualquer parte do nome de um produto e apresentar seu código, nome e quantidade de vendas em ordem alfabética do nome do produto de forma decrescente.

SELECT p.idProduto, p.descricao, COUNT(c.quantidade) AS total_vendas
	FROM PRODUTO p
		INNER JOIN compoe c ON p.idProduto = c.idProduto
			WHERE p.descricao LIKE '%Caneta%'
				GROUP BY p.idProduto, p.descricao
					ORDER BY p.descricao DESC;