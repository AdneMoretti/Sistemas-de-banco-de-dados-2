-- ---------------------   << Exercício 1 da Aula 3 Evolucao 2 >>   ---------------------
--
--                    			SCRIPT POPULA (DML)
-- 
-- Data Criacao ...........: 24/04/2023
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL8.0
-- Base de Dados(nome) ...: aula3exer1Evolucao2
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
-- 		   => 03 perfis
-- 		   => 05 usuarios
-- 
-- -----------------------------------------------------------------

USE aula3exer1Evolucao2;

DROP TABLE possui;
DROP TABLE pertence;
DROP TABLE ESPECIALIDADE;
DROP TABLE PLANTONISTA;
DROP TABLE SETOR;
DROP USER saudedba;
DROP USER maria;
DROP USER jose;
DROP USER clara;
DROP USER joaquim;
DROP ROLE administrador;
DROP ROLE usuario;
DROP ROLE gestor;



 