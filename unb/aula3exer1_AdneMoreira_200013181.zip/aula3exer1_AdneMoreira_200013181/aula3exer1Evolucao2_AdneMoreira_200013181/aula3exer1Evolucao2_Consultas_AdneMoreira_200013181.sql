-- ---------------------   << Exercício 1 da Aula 3 Evolucao 2 >>   ---------------------
--
--                    			SCRIPT DE CONSULTAS (DML)
-- 
-- Data Criacao ...........: 03/05/2023
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL8.0
-- Base de Dados(nome) ...: aula3exer1Evolucao2
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
-- 		   => 03 perfis
-- 		   => 05 usuarios
--
-- -----------------------------------------------------------------

USE aula3exer1Evolucao2;

-- 1)  Indicar todos os plantonistas por um setor específico fornecido pelo usuário da consulta, que será apresentada em ordem decrescente de horário;
SELECT P.* FROM PLANTONISTA P
	JOIN pertence ON pertence.matriculaFuncional = P.matriculaFuncional
		JOIN SETOR s ON pertence.idSetor = s.idSetor WHERE nomeSetor="GINECOLOGIA"
			ORDER BY pertence.horarioAlocado DESC;
            
-- 2)  Mostrar todos os plantonistas em uma data fornecida pelo usuário em ordem crescente de data (consulta no padrão DE__  ATÉ__  para datas), em que o DE e o ATÉ serão fornecidos pelo usuário;
SELECT P.* FROM PLANTONISTA P 
	JOIN pertence ON P.matriculaFuncional = pertence.matriculaFuncional 
		WHERE pertence.horarioAlocado 
			BETWEEN "8:00" AND "16:00";


--  3)  Consulta os plantonistas por parte do nome e mostrar todos os seus dados pessoais cadastrados e em qual setor (ou setores) ele realiza atividades, mostrando somente o nome do setor e os dados pessoais;
SELECT P.*, s.nomeSetor FROM PLANTONISTA P
	JOIN pertence ON pertence.matriculaFuncional = P.matriculaFuncional
		JOIN SETOR s ON pertence.idSetor = s.idSetor WHERE p.nomeCompleto LIKE "%Maria%";
		
-- 4)  Apresentar todas as especialidades e quantos plantonistas têm para cada uma destas especialidades cadastradas, inclusive as que NÃO tiverem plantonista no momento (zero plantonista na especialidade, mas apresentar para usuário saber qual área está sem plantonista).
SELECT E.*, count(possui.matriculaFuncional) FROM ESPECIALIDADE E
	LEFT JOIN possui ON E.idEspecialidade = possui.idEspecialidade
		GROUP BY E.idEspecialidade;
        