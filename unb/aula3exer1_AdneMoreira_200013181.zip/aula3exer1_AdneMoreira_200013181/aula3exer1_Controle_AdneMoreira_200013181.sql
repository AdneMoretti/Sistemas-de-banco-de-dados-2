-- ---------------------   << Exercício 1 da Aula 3 Evolucao 2 >>   ---------------------
--
--                    			SCRIPT DE CONTROLE
-- 
-- Data Criacao ...........: 24/04/2023
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL8.0
-- Base de Dados(nome) ...: aula3exer1Evolucao2
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
-- 		   => 03 perfis
-- 		   => 05 usuarios
--
-- -----------------------------------------------------------------

USE aula3exer1Evolucao2;

-- Criação de papeis 
CREATE ROLE administrador;
CREATE ROLE usuario;
CREATE ROLE gestor;

-- Atribuindo privilegios aos papeis
GRANT ALL PRIVILEGES ON aula3exer1.* TO administrador;
GRANT SELECT ON aula3exer1.* TO usuario;
GRANT SELECT, INSERT, UPDATE ON aula3exer1.PLANTONISTA TO gestor;
GRANT SELECT, INSERT, UPDATE ON aula3exer1.SETOR TO gestor;

-- Criando os usuários
CREATE USER saudedba  IDENTIFIED BY 'dbsaude';
CREATE USER maria IDENTIFIED BY 'airam';
CREATE USER jose IDENTIFIED BY 'esoj';
CREATE USER clara IDENTIFIED BY 'c1234';
CREATE USER joaquim IDENTIFIED BY 'j4321';
 
 -- Atribuindo papeis aos usuarios
GRANT administrador TO saudedba;
GRANT usuario TO maria;
GRANT usuario TO jose;
GRANT gestor TO clara;
GRANT gestor TO joaquim;


