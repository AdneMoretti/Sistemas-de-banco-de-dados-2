-- ---------------------   << Exercício 1 da Aula 3 Evolucao 2>>   ---------------------
--
--                    			SCRIPT DE CRIAÇÃO (DDL)
-- 
-- Data Criacao ...........: 24/04/2023
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL8.0
-- Base de Dados(nome) ...: aula3exer1Evolucao2 
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
-- 		   => 03 perfis
-- 		   => 05 usuarios
-- 
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula3exer1Evolucao2;
USE aula3exer1Evolucao2;

CREATE TABLE SETOR (
    idSetor INT(5) NOT NULL AUTO_INCREMENT,
    nomeSetor VARCHAR(100) NOT NULL, 
    CONSTRAINT SETOR_PK PRIMARY KEY(idSetor)
)ENGINE = InnoDB;

CREATE TABLE PLANTONISTA (
    nomeCompleto VARCHAR(100) NOT NULL,
    matriculaFuncional INT(10) NOT NULL,
    sexo ENUM('F', 'M') NOT NULL, 
    CONSTRAINT PLANTONISTA_PK PRIMARY KEY(matriculaFuncional)
)ENGINE = InnoDB;

CREATE TABLE ESPECIALIDADE (
    idEspecialidade INT(5) NOT NULL AUTO_INCREMENT,
    nomeEspecialidade VARCHAR(100) NOT NULL, 
    CONSTRAINT ESPECIALIDADE_PK PRIMARY KEY(idEspecialidade)
)ENGINE = InnoDB;

CREATE TABLE pertence (
    idSetor INT(5) NOT NULL,
    matriculaFuncional INT(10) NOT NULL,
    horarioAlocado TIME NOT NULL, 
    CONSTRAINT pertence_SETOR_FK
		FOREIGN KEY (idSetor)
			REFERENCES SETOR(idSetor)
				ON DELETE RESTRICT
					ON UPDATE CASCADE, 
	CONSTRAINT pertence_PLANTONISTA_FK
		FOREIGN KEY (matriculaFuncional)
			REFERENCES PLANTONISTA(matriculaFuncional)
				ON DELETE RESTRICT
					ON UPDATE CASCADE, 
	CONSTRAINT pertence_UK UNIQUE KEY(matriculaFuncional, horarioAlocado)
)ENGINE = InnoDB;

CREATE TABLE possui (
    matriculaFuncional INT(10),
    idEspecialidade INT(5),
    CONSTRAINT possui_SETOR_FK
		FOREIGN KEY (matriculaFuncional)
			REFERENCES PLANTONISTA(matriculaFuncional)
				ON DELETE RESTRICT
					ON UPDATE CASCADE,
	CONSTRAINT possui_ESPECIALIDADE_FK
		FOREIGN KEY (idEspecialidade)
			REFERENCES ESPECIALIDADE(idEspecialidade)
				ON DELETE RESTRICT
					ON UPDATE CASCADE, 
	CONSTRAINT pertence_UK UNIQUE KEY(matriculaFuncional, idEspecialidade)
)ENGINE = InnoDB;
 