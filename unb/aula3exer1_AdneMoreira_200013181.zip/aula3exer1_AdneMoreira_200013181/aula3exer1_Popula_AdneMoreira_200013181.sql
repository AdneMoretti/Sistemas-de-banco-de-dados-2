-- ---------------------   << Exercício 1 da Aula 3 Evolucao 2 >>   ---------------------
--
--                    			SCRIPT POPULA (DML)
-- 
-- Data Criacao ...........: 24/04/2023
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL8.0
-- Base de Dados(nome) ...: aula3exer1Evolucao2
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
--
-- Ultimas alteracoes
-- 		   => 03/05/2023 - Adicionando mais 2 tuplas em cada tabela
--
-- -----------------------------------------------------------------

USE aula3exer1Evolucao2;

INSERT INTO SETOR(nomeSetor) VALUES
("ORTOPEDICO"), 
("PEDIATRIA"),
("NEUROLOGIA"),
("ONCOLOGIA"), 
("DERMATOLOGIA"),
("GINECOLOGIA"),
("UROLOGIA");

INSERT INTO PLANTONISTA(nomeCompleto,matriculaFuncional,sexo) VALUES 
("Gabriel Oliverira", 283921352, 'F'),
("Ana Souza", 123456789, "F"),
("João Silva", 987654321, "M"),
("Carla Oliveira", 456789123, "F"),
("Pedro Santos", 321654987, "M"), 
("Paulo Santos", 234567890, "M"),
("Maria Silva", 567890123, "F");

INSERT INTO ESPECIALIDADE(nomeEspecialidade) VALUES
("CARDIOLOGISTA"), 
("NEUROLOGISTA"),
("GINECOLOGISTA"),
("ORTOPEDISTA"),
("DERMATOLOGISTA"),
("CLINICO GERAL"), 
("GINECOLOGISTA"),
("UROLOGISTA");

INSERT pertence (idSetor, matriculaFuncional, horarioAlocado) VALUES 
(1, 283921352, '08:00'), 
(2, 123456789, "08:00"),
(3, 987654321, "12:00"),
(4, 456789123, "16:00"),
(5, 321654987, "20:00"),
(4, 321654987, "15:00"),
(6, 567890123, "17:00"),
(6, 234567890, "10:00");

INSERT INTO possui (matriculaFuncional,idEspecialidade) VALUES 
(123456789, 1),
(987654321, 2),
(456789123, 3),
(321654987, 4),
(283921352, 5),
(567890123, 6), 
(234567890, 4);
 