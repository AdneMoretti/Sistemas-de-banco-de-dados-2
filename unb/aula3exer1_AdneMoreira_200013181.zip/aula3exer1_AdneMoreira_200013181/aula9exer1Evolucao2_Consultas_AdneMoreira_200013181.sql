USE metagame;
-- 1) Nome do jogo e da publicadora que possuem e nota de avaliação da metacritic ordenados em ordem decrescente de nota de avaliação 
-- com o objetivo de identificar as publicadoras com jogos mais bem avaliados 
SELECT G.name, P.publisher_name, G.critic_score 
	FROM GAME G, PUBLISHER P 
		WHERE P.id_publisher = G.id_publisher 
			ORDER BY G.user_count DESC;

-- 2) Contar a quantidade de jogos publicado pela publicadora que sao de determinado tipo de genero 
-- com o objetivo de conhecer quais publicadoras se voltam para quais generos de jogos+
SELECT P.publisher_name, GN.description, COUNT(GN.description) AS quantidade
	FROM GENRE GN, 
		GAME G JOIN PUBLISHER P ON P.id_publisher = G.id_publisher 
			WHERE G.id_genre = GN.id_genre 
				GROUP BY P.publisher_name, GN.description 
					ORDER BY quantidade DESC;

-- 3) Quantidade de usuários por gênero de jogo, importante para saber quais os generos mais jogados para possivel criacao de 
-- um jogo com uma boa audiência
CREATE VIEW GENRE_USERS_COUNT_VIEW AS SELECT GN.description, SUM(G.user_count) AS quantidade_usuarios
	FROM GAME G, GENRE GN WHERE G.id_genre = GN.id_genre
		GROUP BY G.id_genre, GN.description
			ORDER BY quantidade_usuarios DESC;
            
