
CREATE DATABASE teste;
USE teste;

CREATE TABLE JOGO
(idJogo INT NOT NULL,
 idLocal INT NOT NULL);
 
CREATE TABLE PARTIDA(
idTimeLocal INT NOT NULL, 
idVisitante INT NOT NULL, 
idJogo INT NOT NULL);
 
CREATE TABLE LOCAL (idLocal INT NOT NULL, 
dsLocal VARCHAR(50) NOT NULL);

INSERT INTO JOGO (idJogo, idLocal) VALUES
(1, 100),
(2, 101),
(3, 102);


INSERT INTO PARTIDA (idTimeLocal, idVisitante, idJogo) VALUES
(10, 20, 1),
(15, 18, 2),
(12, 25, 3);

INSERT INTO LOCAL (idLocal, dsLocal) VALUES
(100, 'Estádio do Pacaembu'),
(101, 'Arena Corinthians'),
(102, 'Estádio do Morumbi');

DROP VIEW V_LOCAIS;
CREATE VIEW V_LOCAIS AS SELECT L.dsLocal AS LOCAL, COUNT(*) AS QUANTIDADE FROM LOCAL L JOIN JOGO J ON L.idLocal = J.idLocal JOIN PARTIDA P ON J.idJogo = P.idJogo GROUP BY L.idLocal;

SELECT * FROM V_LOCAIS;