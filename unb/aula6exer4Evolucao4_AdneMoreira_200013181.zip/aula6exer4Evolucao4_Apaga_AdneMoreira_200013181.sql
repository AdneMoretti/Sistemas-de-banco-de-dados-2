/*﻿-- --------  << aula6exer4evolucao4 >>  ----------
--
--                    SCRIPT DE APAGAR (DDL)
--
-- Data Criacao ...........: 25/01/2023
-- Autor(es) ..............: Alex Gabriel Alves Faustino, Adne Moretti Moreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula6exer4evolucao2
--
-- Ultimas Alteracoes
--   01/02/23 => Adição de DROP USER para funcionario e administrador
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- ---------------------------------------------------------*/

USE aula6exer4evolucao4;

DROP USER funcionario;
DROP USER administrador;
DROP TABLE tem;
DROP TABLE gerencia;
DROP TABLE trabalha;
DROP TABLE supervisiona;
DROP TABLE DEPENDENTE;
DROP TABLE PROJETO;
DROP TABLE LOCAL;
DROP TABLE EMPREGADO;
DROP TABLE DEPARTAMENTO;