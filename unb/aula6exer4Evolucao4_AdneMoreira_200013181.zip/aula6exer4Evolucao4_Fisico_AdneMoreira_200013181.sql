﻿-- --------  << aula6exer4evolucao4 >>  ----------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 25/01/2023
-- Autor(es) ..............: Alex Gabriel Alves Faustino
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula6exer4evolucao4
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- ---------------------------------------------------------*/

CREATE DATABASE IF NOT EXISTS aula6exer4evolucao4;

USE aula6exer4evolucao4;

CREATE TABLE DEPARTAMENTO (
	numeroDepartamento INT NOT NULL, 
    nomeDepartamento VARCHAR(50) NOT NULL,
    
    CONSTRAINT DEPARTAMENTO_PK PRIMARY KEY (numeroDepartamento)
)ENGINE = InnoDB;

CREATE TABLE EMPREGADO (
    matricula VARCHAR(15),
    numeroDepartamento INT,
    nomeEmpregado VARCHAR(100) NOT NULL,
    salario DECIMAL(7,2) NOT NULL,
    sexo ENUM('M','F') NOT NULL,
    dtNascimento DATE NOT NULL,
    rua VARCHAR(50) NOT NULL,
    numero INT NOT NULL,
    bairro VARCHAR(50),
    
    CONSTRAINT EMPREGADO_PK PRIMARY KEY (matricula),
    CONSTRAINT EMPREGADO_DEPARTAMENTO_FK FOREIGN KEY (numeroDepartamento)
    REFERENCES DEPARTAMENTO (numeroDepartamento)
)ENGINE = InnoDB;

CREATE TABLE LOCAL (
    idLocal INT NOT NULL,
    descricaoLocal VARCHAR(50) NOT NULL,
    
    CONSTRAINT LOCAL_PK PRIMARY KEY (idLocal)
)ENGINE = InnoDB;

CREATE TABLE PROJETO (
    numeroProjeto INT NOT NULL,
    numeroDepartamento INT NOT NULL,
    nomeProjeto VARCHAR(100) NOT NULL,
    idLocal INT NOT NULL,
    
    CONSTRAINT PROJETO_PK PRIMARY KEY (numeroProjeto),
    CONSTRAINT PROJETO_DEPARTAMENTO_FK FOREIGN KEY (numeroDepartamento)
    REFERENCES DEPARTAMENTO (numeroDepartamento),
    CONSTRAINT PROJETO_LOCAL_FK FOREIGN KEY (idLocal)
    REFERENCES LOCAL (idLocal)
)ENGINE = InnoDB;

CREATE TABLE DEPENDENTE (
    idDependente INT NOT NULL,
    matricula VARCHAR(15) NOT NULL,
    nomeDependente VARCHAR(100) NOT NULL,
    sexoDependente ENUM('M','F') NOT NULL,
    dtNascimentoDepedente DATE NOT NULL,
    parentesco VARCHAR(30) NOT NULL,
    
    CONSTRAINT DEPEDENTE_PK PRIMARY KEY (idDependente),
    CONSTRAINT DEPEDENTE_EMPREGADO_FK FOREIGN KEY (matricula)
    REFERENCES EMPREGADO (matricula)
)ENGINE = InnoDB;

CREATE TABLE supervisiona (
    matriculaEmpregado VARCHAR(15),
    matriculaSupervisor VARCHAR(15),
    
    CONSTRAINT supervisiona_PK PRIMARY KEY (matriculaEmpregado),
    CONSTRAINT supervisionado_EMPREGADO_FK  FOREIGN KEY (matriculaEmpregado)
    REFERENCES EMPREGADO (matricula),
    CONSTRAINT supervisionador_EMPREGADO_FK  FOREIGN KEY (matriculaSupervisor)
    REFERENCES EMPREGADO (matricula)
)ENGINE = InnoDB;

CREATE TABLE trabalha (
	matricula VARCHAR(15) NOT NULL,
    numeroProjeto INT NOT NULL,
    horasSemanais int NOT NULL,
    
    CONSTRAINT trabalha_PROJETO_FK FOREIGN KEY (numeroProjeto)
    REFERENCES PROJETO (numeroProjeto),
	CONSTRAINT trabalha_EMPREGADO_FK FOREIGN KEY (matricula)
    REFERENCES EMPREGADO (matricula) 
)ENGINE = InnoDB;

CREATE TABLE gerencia (
    matricula VARCHAR(15) NOT NULL,
    numeroDepartamento INT NOT NULL,
    dataInicio DATE NOT NULL,
    
    CONSTRAINT gerencia_EMPREGADO_FK FOREIGN KEY (matricula)
    REFERENCES EMPREGADO (matricula),
    CONSTRAINT gerencia_DEPARTAMENTO_FK FOREIGN KEY (numeroDepartamento)
    REFERENCES DEPARTAMENTO (numeroDepartamento)
)ENGINE = InnoDB;

CREATE TABLE tem (
    idLocal INT NOT NULL,
    numeroDepartamento INT NOT NULL,
    
    CONSTRAINT tem_LOCAL_FK FOREIGN KEY (idLocal)
    REFERENCES LOCAL (idLocal),
    CONSTRAINT tem_DEPARTAMENTO_FK FOREIGN KEY (numeroDepartamento)
    REFERENCES DEPARTAMENTO (numeroDepartamento)
)ENGINE = InnoDB;
 