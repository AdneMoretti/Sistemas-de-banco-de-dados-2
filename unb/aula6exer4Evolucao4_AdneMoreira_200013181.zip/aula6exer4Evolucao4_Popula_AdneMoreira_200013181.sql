/*﻿-- --------  << aula6exer4evolucao4 >>  ----------
--
--                    SCRIPT DE POPULAR (DML)
--
-- Data Criacao ...........: 25/01/2023
-- Autor(es) ..............: Alex Gabriel Alves Faustino, Adne Moretti Moreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: aula6exer4evolucao2
--
-- Ultimas Alteracoes
--   01/02/23 => Adição de mais 2 tuplas para cada tabela
--
--
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- ---------------------------------------------------------*/

USE aula6exer4evolucao4;

INSERT INTO DEPARTAMENTO VALUES
	(1, 'Requisitos'),
	(2, 'Interação humano-computador'),
	(3, 'Testes'),
	(4, 'Desenvolvimento'),
    (5, 'verificação'),
    (6, 'cenarios'), 
    (7, 'Qualidade'),
    (8, 'Arquitetura');

INSERT INTO EMPREGADO VALUES
	('20R34',1,'Carolina Cláudia das Neves', 1300.00, 'F', '1990-08-07','Rua Idezuite Miguel Gomes', 710, 'Loteamento Quitéria Teruel Lopes'),
	('32I21',2,'Ruan Rodrigo Davi da Cruz', 1500.00, 'M', '1999-09-20','Rua Luanda', 144, 'Tomba'),
	('94T23',3,'Tiago Daniel da Costa', 1600.00,'M' ,'1993-02-12','Rua Auxiliar II' ,244, 'Santa Maria'),
	('93D93',4,'Valentina Alana Almeida', 1200.00, 'F', '1995-01-23','Conjunto 1ª Etapa Conjunto J' ,647 ,'Recanto das Emas'),
    ('48J33',5,'Daniel da Silva Junior', 1650.00,'M' ,'1994-02-11','Rua Auxiliar I' ,240, 'Santa Maria'),
    ('12D44',6,'Rodrigo da Costa Nunes', 1340.00,'M' ,'1996-01-12','Rua Auxiliar III' ,24, 'Santa Maria'), 
    ('19A12',7,'Andreia Mascarelo', 1110.00,'F' ,'1998-12-11','Quadra 28' ,12, 'Cruzeiro Velho'), 
    ('33S42',1,'Giovana dos Santos', 1000.00,'F' ,'1990-10-01','Quadra 401 D' ,10, 'Cruzeiro Novo');
    
INSERT INTO LOCAL VALUES
	(1, 'sala 1'),
    (2, 'sala 2'),
    (3, 'sala 3'),
    (4, 'sala 4'),
    (5, 'sala 5'),
    (6, 'sala 6'), 
	(7, 'sala 7'), 
	(8, 'sala 8');
    
INSERT INTO PROJETO VALUES
	(1, 1, 'Habitica web', 1),
    (2, 2, 'teammates mobile', 2),
    (3, 3, 'Kioto 2', 3),
    (4, 4, 'Telemaker web', 4),
    (5, 5, 'dancem Mobile', 5),
    (6, 6, 'ROTA web',6), 
    (7, 7, 'ROTA app',7), 
    (8, 8, 'Boscov' , 8);
    
INSERT INTO dependente VALUES
	(1, '20R34','Luciana Antônia da Mota', 'F', '2005-08-07','Filha'),
	(2, '32I21','Leonardo Danilo Freitas', 'M', '2011-09-20','Filho'),
	(3, '94T23','Igor Diego Pinto','M' ,'2016-02-12','Neto' ),
	(4, '93D93','Brenda Sophia Galvão', 'F', '2023-01-23','Filha'),
    (5, '48J33', 'Vanesso da mata matos', 'F', '2015-04-20', 'sobrinho'),
    (6,'12D44','Joelma calipsu de jesus', 'F', '2016-06-12', 'filha'), 
    (7,'19A12','Gabriel', 'M', '2006-10-12', 'filho'), 
    (8,'33S42','Cristiane Moreira', 'F', '2007-07-11', 'neta');
    
INSERT INTO trabalha VALUES
	('20R34', 1, 44),
    ('32I21', 2, 40),
    ('94T23', 3, 44),
    ('93D93', 4, 44),
    ('48J33', 5, 44),
    ('12D44', 6, 44), 
    ('19A12', 7, 40), 
    ('33S42', 8, 30);
    
INSERT INTO gerencia VALUES
	('20R34', 1, '2020-07-15'),
    ('32I21', 2, '2022-08-17'),
    ('94T23', 3, '2021-12-22'),
    ('93D93', 4, '2011-11-30'),
    ('48J33', 5, '2013-10-12'),
    ('12D44', 6, '2016-09-25'), 
	('19A12', 7, '2016-09-25'), 
    ('33S42', 8, '2016-09-25');
    
INSERT INTO supervisiona VALUES
	('93D93','20R34'),
    ('94T23','93D93'),
    ('32I21','94T23'),
    ('20R34','32I21'),
    ('48J33','12D44'),
    ('12D44','48J33'), 
    ('19A12', '12D44');
    
    
INSERT INTO tem VALUES
	(1,1),
    (2,2),
    (3,3),
    (4,4),
    (5,5),
    (6,6), 
    (7,7), 
    (8,8);
    
