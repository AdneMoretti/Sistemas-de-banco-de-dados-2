-- --------     << AULA 6 EXERCICIO 4 >>     ------------
--
--                    SCRIPT APAGA (DML)
--
-- Data Criacao ...........: 02/01/2022
-- Autor(es) ..............: Paulo Rezende, Adne Moretti
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula6exer4Evolucao2
--
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
-- -------------------------------------------------------------

DROP TABLE participa;
DROP TABLE DEPENDENTE;
DROP TABLE PROJETO;
DROP TABLE EMPREGADO;
DROP TABLE DEPARTAMENTO;
DROP TABLE LOCALIZACAO;