-- --------     << AULA 6 EXERCICIO 4 EVOLUCAO 2>>     ------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 02/01/2022
-- Autor(es) ..............: Paulo Rezende, Adne Moretti
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula6exer4Evolucao2
--
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
-- -----------------------------------------------------------------

CREATE DATABASE IF NOT EXISTS aula6exer4Evolucao2;
-- DROP DATABASE aula6exer4Evolucao2;
USE aula6exer4Evolucao2;

CREATE TABLE
    DEPARTAMENTO(
        idDepartamento INT NOT NULL AUTO_INCREMENT,
        nome VARCHAR(30) NOT NULL,
        numero BIGINT NOT NULL,
        CONSTRAINT DEPARTAMENTO_PK PRIMARY KEY (idDepartamento)
    )engine = InnoDB;

CREATE TABLE
    EMPREGADO(
        matriculaEmpregado BIGINT NOT NULL,
        nome VARCHAR(30) NOT NULL,
        dataInicio DATE NOT NULL,
        salario DECIMAL(10, 2) NOT NULL,
        sexo ENUM('F', 'M') NOT NULL,
        dataNascimento DATE NOT NULL,
        bairro VARCHAR(90) NOT NULL,
        numero VARCHAR(30) NOT NULL,
        rua VARCHAR(90) NOT NULL,
        idDepartamento INT NOT NULL,
        CONSTRAINT EMPREGADO_PK PRIMARY KEY (matriculaEmpregado),
        CONSTRAINT EMPREGADO_DEPARTAMENTO_FK FOREIGN KEY (idDepartamento) REFERENCES DEPARTAMENTO (idDepartamento), 
        CONSTRAINT EMPREGADO_EMPREGADO_FK FOREIGN KEY (matriculaEmpregado) REFERENCES DEPARTAMENTO (matriculaEmpregado)
    ) engine = InnoDB;

CREATE TABLE
    LOCALIZACAO(
        idLocalizacao INT NOT NULL AUTO_INCREMENT,
        predio VARCHAR(20) NOT NULL,
        setor VARCHAR(20) NOT NULL,
        sala INT NOT NULL,
        idDepartamento INT,
        CONSTRAINT LOCALIZACAO PRIMARY KEY (idLocalizacao), 
        CONSTRAINT LOCALIZACAO_DEPARTAMENTO_FK FOREIGN KEY (idDepartamento) REFERENCES DEPARTAMENTO (idDepartamento)
    )engine = InnoDB;

CREATE TABLE
    DEPENDENTE(
        idDependente INT NOT NULL AUTO_INCREMENT,
        nome VARCHAR(30) NOT NULL,
        sexo ENUM('F', 'M') NOT NULL,
        dataNascimento DATE NOT NULL,
        idEmpregado INT NOT NULL,
        CONSTRAINT DEPENDENTE_PK PRIMARY KEY (idDependente),
        CONSTRAINT DEPENDENTE_EMPREGADO_FK FOREIGN KEY (idEmpregado) REFERENCES EMPREGADO (idEmpregado)
    )engine = InnoDB;

CREATE TABLE
    PROJETO(
        idProjeto INT NOT NULL AUTO_INCREMENT,
        nomeProjeto VARCHAR(40) NOT NULL,
        numero BIGINT NOT NULL,
        idLocalizacao INT NOT NULL,
        idDepartamento INT NOT NULL,
        CONSTRAINT PROJETO_PK PRIMARY KEY (idProjeto),
        CONSTRAINT PROJETO_localizacao_FK FOREIGN KEY (idLocalizacao) REFERENCES localizacao (idLocalizacao),
        CONSTRAINT PROJETO_DEPARTAMENTO_FK FOREIGN KEY (idDepartamento) REFERENCES DEPARTAMENTO (idDepartamento)
    )engine = InnoDB;
    
    
    CREATE TABLE
    participa(
        horasSemanais TIME NOT NULL,
        matriculaEmpregado BIGINT NOT NULL,
        idProjeto INT NOT NULL,
        CONSTRAINT participa_PROJETO_FK FOREIGN KEY (idProjeto) REFERENCES PROJETO (idProjeto),
        CONSTRAINT participa_EMPREGADO_FK FOREIGN KEY (matriculaEmpregado) REFERENCES EMPREGADO (matriculaEmpregado)
    )engine = InnoDB;