-- --------     << AULA 6 EXERCICIO 4 EVOLUCAO 2>>     ------------
--
--                    SCRIPT POPULA (DML)
--
-- Data Criacao ...........: 02/01/2022
-- Autor(es) ..............: Paulo Rezende, Adne Moretti
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: aula6exer4
--
--
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
-- -----------------------------------------------------------------

INSERT INTO
    DEPARTAMENTO(nome, numero)
VALUES ('A', 1), ('B', 2), ('C', 3), ('D', 4);

INSERT INTO
    EMPREGADO(
        nome,
        dataInicio,
        matriculaEmpregado,
        salario,
        sexo,
        dataNascimento,
        bairro,
        numeroEndereco,
        rua,
        idDepartamento
    )
VALUES (
        'Pedro',
        '2020-02-02',
        1,
        2000.00,
        'F',
        '2000-02-03',
        'Bairro Vila bela',
        'Casa 13',
        'Rua mata grosso',
        1
    ), (
        'Moises',
        '2021-02-02',
        2,
        2000.00,
        'M',
        '2001-02-03',
        'Bairro Matilde',
        '14',
        'Rua Amazona',
        2
    ), (
        'Fabricio',
        '2020-02-02',
        3,
        2000.00,
        'M',
        '2000-03-06',
        'Bairro Rabêlo',
        'Casa 13',
        'Rua Acre',
        3
    ), (
        'Pedro',
        '2020-02-02',
        4,
        2000.00,
        'M',
        '2000-02-04',
        'Bairro Franca',
        'Casa 16',
        'Rua Goias',
        4
    );

INSERT INTO
    LOCALIZACAO(predio, setor, sala, idDepartamento)
VALUES (
        'A', 'D', 1, 2,
        'B', 'E', 3, 1,
        'C', 'F', 4, 3,
        'E', 'G', 2, 4
    );

INSERT INTO
    DEPENDENTE(
        nome,
        sexo,
        dataNascimento,
		matriculaEmpregado
    )
VALUES ('Matheus', 'M', '2000-02-02', 1), (
        'Fabricio',
        'M',
        '2000-02-02',
        1
    ), ('Maria', 'F', '2002-02-02', 1), ('Mariana', 'F', '2001-02-02', 1);

INSERT INTO
    PROJETO(
        nomeProjeto,
        numero,
        idLocalizacao,
        idEmpregado
    )
VALUES ('Paçoca', 1, 2, 1), ('Paçoca', 2, 1,  2), ('Paçoca', 3, 4, 3), ('Paçoca', 4, 3, 4);

INSERT INTO
    participa
VALUES ('30:00:00', 1, 2), ('50:00', 2, 1), ('25:00', 3, 4), ('20:00', 4, 3);