﻿-- ------------ p1AdneMoreira ----------------
--
--                    SCRIPT DE CRIACAO (DDL)
--
-- Data Criacao ...........: 01/06/2023
-- Autor(es) ..............: Adne Moretti Moreira
-- Banco de Dados .........: MySQL 8.0
-- Base de Dados (nome) ...: bdFinanceiro
--
-- PROJETO => 01 Base de Dados
--         => 03 Tabelas
--         => 01 Visoes
-- 
-- ---------------------------------------------------------
USE mercado;

-- AA: 
-- A consulta consiste em visualizar id da loja, tipo da loja, departamento da venda
-- e a soma da quantidade de vendas por dia.
-- Consulta importante para a diretoria entender quais as lojas que precisam de maior quantidade de funcionários
-- trabalhando de forma a atender corretamente os clientes
-- 
SELECT S.idStore, S.`type`, COUNT(V.idStore) as quantidade_vendas
	FROM STORE S JOIN VENDAS_SEMANAIS V 
    ON V.idStore = S.idStore
    WHERE V.isHoliday = 1
    GROUP BY S.idStore
    ORDER BY quantidade_vendas DESC;
    
-- A consulta em questão não precisa de índice, pois está sendo agrupado e ordenado
-- pelo idStore, que e uma chave primaria da loja, e assim, ja possui indice

-- BB
-- Mostrar o numero de vendas das lojas em dias que sao feriados ordenados por ordem decrescente
-- Consulta importante para a diretoria entender quais as lojas que precisam de maior quantidade de funcionários
-- trabalhando de forma a atender corretamente os clientes
CREATE OR REPLACE VIEW vTipo AS SELECT S.idStore, S.`type`, SUM(V.weeklySales) as valor_arrecadado
	FROM STORE S JOIN VENDAS_SEMANAIS V 
    ON V.idStore = S.idStore
    GROUP BY S.idStore, S.`type`
    ORDER BY valor_arrecadado DESC;
    
SELECT * FROM vTipo WHERE idStore=1;

-- Seria interessante a criação de um indice para o atributo tipo, que nao possui indice, a criacao poderia ser por meio do seguinte comando 
-- CREATE INDEX type_store ON STORE(type);

