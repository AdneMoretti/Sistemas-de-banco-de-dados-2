#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int solve(int n){
    int a, b;
    int maior = 0;
    int indice = 0;
    for(int j=0;j<n;j++){
        cin >> a >> b;
        if(a <= 10 and b > maior){
            maior = b;
            indice = j+1;
        }
    }
    return indice;
}
int main(){
    int t, n;
    cin >> t;
    for(int i=0;i<t;i++){
        cin >> n;
        cout << solve(n) << endl;
    }
    return 0;
}