#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main()
{
    int a, b, c, n;
    cin >> n;
    for(int i=0;i<n; i++)
    {
        vector<int> memoization ;
        cin >> a >> b >> c;
        memoization.push_back(a);
        memoization.push_back(b);
        memoization.push_back(c);
        if(a+b >=10 or a+c >=10 or b+c>=10){
            cout << "YES" << endl;
        }
        else{
            cout << "NO" << endl;
        }
    }
    return 0;
}